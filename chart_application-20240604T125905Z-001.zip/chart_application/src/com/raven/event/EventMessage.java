package com.raven.event;

import com.raven.model.Model_Message;

public interface EventMessage {

    public void callMessage(Model_Message message);
}
